# 015-set-field

## real problem situation
Musicians building setlists for live shows cannot see the harmonic and energy relationships between songs. They work from text lists and have to hold all the key, tempo, and energy relationships in their heads. When two adjacent songs are in distant keys or have jarring tempo changes, the awkward transition only becomes obvious during rehearsal or worse, on stage. The list format hides the very thing that matters most: how one song flows into the next.

## what was built
A harmonic flow instrument. Songs are placed on a circle of fifths according to their key, with the setlist path drawn through harmonic space. Transition quality is immediately visible as physical distance on the circle — smooth transitions are short paths between nearby keys, jarring transitions are long paths crossing the field. Node size encodes energy, and two sparklines show energy and tempo arcs below the field. A linear setlist readout with color-coded transition badges completes the picture.

## why this form was chosen
Musical relationships between songs are inherently spatial (the circle of fifths is the fundamental map of key relationships). A list hides these relationships. The circle makes them visible. The path through the field IS the setlist, and its shape tells you whether the flow works. This is a case where the form is native to the problem — the visualization and the insight are the same thing.

## what is actually interesting here
- It makes harmonic distance between songs newly visible. A text setlist says "Am, then E" — the field shows that's a 4-step jump across the circle.
- The path shape immediately reveals problem zones. Three red lines in a row screams "this section has no harmonic flow" without any label saying so.
- Energy and tempo are secondary reads, not primary. The circle carries the harmonic insight; the sparklines add context without competing.
- It stays out of the trap of becoming a setlist management CRUD app. There's no "add song" form. The instrument is the artifact.

## iterations made
- v1.1: Increased angular spread for nodes sharing key positions (C major has two songs) and suppressed key badges on crowded nodes to reduce visual noise in the dense harmonic areas.

## next step
Add drag-to-reorder on the circle so a musician can experiment with different song orders and watch the path redraw in real time. The field should make it obvious when a reorder improves or worsens harmonic flow — the path shape changes, the cohesion score updates, and the sparklines shift.

## art direction note
Dark editorial treatment. The dark background fits the performance domain (stages, music software). Warm gold/sand nodes evoke stage lighting. Path colors go from restrained green (smooth) through amber (stretch) to warm red (jump). Typography follows the default Night Lab pairing: Geist for content, JetBrains Mono for labels and metadata.

## promotion candidate read
Maybe. The form feels genuinely native to the problem — the circle of fifths is not a metaphor, it's the actual structural framework that governs key relationships. The artifact makes something invisible (harmonic flow through a setlist) newly visible. But it needs the drag-to-reorder interaction to become genuinely useful rather than only diagnostic.
