# v1.1 implemented

Implemented:
- month scrubber for jan / feb / mar / full trace
- field can now be read as a temporal object, not only a composite map
- selected signal stays legible while the atlas shifts across time modes

Still missing:
- editable signals in the ledger
- adjustable threshold line
- domain / state filters
- stronger contour / mathematical field treatment
