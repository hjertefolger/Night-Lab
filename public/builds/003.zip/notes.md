# v1.2 implemented

Implemented:
- removed explanatory/meta-product copy from the build surface so the artifact stands on its own
- expanded the map into the primary full-surface experience instead of boxing it into a smaller sub-panel
- tightened the right-side ledger into a true companion surface rather than a competing content block

Still missing:
- editable signals in the ledger
- adjustable threshold line
- stronger contour / mathematical field treatment
