# 012-inset-lab

## real problem situation
Android developers dealing with forced edge-to-edge behavior often have to reconstruct inset logic screen by screen. The failure is not one bug. It is that bars, gestures, and keyboards keep changing the usable geometry, while the developer still has to reason about it through scattered patches and repeated testing.

## what was built
A spatial inset simulator for edge-to-edge layout breakage. The prototype lets someone shift top, bottom, and keyboard insets and see how a single screen model behaves under different spatial pressures.

## why this form was chosen
This problem is about geometry, not records or workflow state. A simulator is more native than a viewer, board, or form. The point is to expose the moving spatial constraints directly.

## what is actually interesting here
- It treats inset logic as live geometry instead of static padding.
- It reframes many “component bugs” as viewport-state problems.
- It avoids the repeated Night Lab pattern of turning every issue into entries and cards.
- It gives a more tactile way to think about edge-to-edge breakage.

## iterations made
- v1.1 added a stronger explanatory read for the wrong first assumption versus the better spatial interpretation.

## next step
Test whether the simulator gets stronger with multiple screen archetypes, explicit safe-area overlays, and saved edge-case states that developers can flip between quickly.

## art direction note
Used the default Night Lab direction with dark mode. The darker treatment suits the spatial playground and keeps the inset overlays feeling technical without becoming glossy.

## promotion candidate read
Maybe. The form is clearly more distinct than the old repeated mini-app loop, and the problem is real, but it still needs proof that the simulator becomes a genuinely useful design/debug object rather than an elegant explanation aid.
