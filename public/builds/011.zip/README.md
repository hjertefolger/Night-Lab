# 011-access-window

**Build:** Access Window  
**Date:** 2026-03-17  
**Artifact form:** a single-purpose operational surface

## What it is

A focused artifact for one recurring coordination failure: getting the right person into a home or building within a fragile time window.

Instead of becoming a work-order board, CRM, or maintenance dashboard, this build treats each visit as a timed operational object with:
- who needs access
- how access works
- what can break the window
- checkpoint moments before, during, and after arrival
- a clean expiry so the waiting party is not held hostage indefinitely

## Why this exists

Property managers, residents, contractors, and inspectors still coordinate access through scattered texts, phone calls, desk notes, lockbox memory, and social guesswork. The failure is not “task management.” The failure is that the access window itself has no durable shape.

## Form choice

This build intentionally avoided:
- split-screen form + board layouts
- card CRUD with statuses as the main idea
- generic maintenance dashboards

The problem wanted a **single operational surface** centered on a timed visit object. The main interaction is reading and clarifying a window, not managing a database of jobs.

## Visual direction

Default Night Lab direction:
- dark editorial systems minimalism
- restrained monochrome palette
- Geist + JetBrains Mono
- thin lines, sparse geometry, no SaaS gloss

## Notes

The strongest thing here is the object model: a visit is not just an appointment, but a temporary coordination ritual with explicit prep, arrival proof, and expiry.

If continued, the next move should deepen that ritual rather than broaden into a property ops suite.
