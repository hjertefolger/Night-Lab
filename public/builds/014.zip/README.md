# 014-refill-orbit

## real problem situation
People managing several ongoing prescriptions often do not fail because they forgot a refill exists. They fail because the refill windows do not line up. One medication becomes the true blocker for a trip, a pickup plan, or a doctor-office chase, but that constraint is hard to see when everything lives as separate reminders, bottles, portal messages, and insurance rules.

## what was built
A visual refill alignment instrument. Instead of acting like a medication list or reminder app, it shows a month as overlapping depletion arcs, refill windows, and away-time conflicts so the user can see which line is quietly dictating the whole month.

## why this form was chosen
This problem wanted a visual instrument, not another planner. The missing thing is not data entry. The missing thing is a way to see how one constrained refill window controls everything else. A circular alignment surface is more native than a form, board, or checklist.

## what is actually interesting here
- It treats refills as an interacting system instead of isolated reminders.
- It makes the blocker legible: the line that quietly controls the trip, pickup, or doctor call.
- It gives travel and refill eligibility equal visual weight, which is where the real stress usually lives.
- It stays out of the Night Lab trap of becoming a medication CRUD app.

## iterations made
- v1.1 added direct line selection inside the orbit so the instrument itself stays primary instead of the side list becoming the real interaction.

## next step
Test a live travel-drag interaction and a “pull this line forward” mode that shows whether partial fills, early fills, or office renewals would actually resolve the month — or only make it look calmer.

## art direction note
Used the default Night Lab editorial direction in a warm light treatment. The lighter paper-toned surface fits the domestic / healthcare-adjacent subject while keeping the artifact restrained, precise, and non-clinical.

## promotion candidate read
Maybe. The form feels more structurally distinct than the recent viewer / repair / simulator run, and the underlying friction is real, but it still needs proof that the alignment instrument becomes operationally useful rather than just elegantly explanatory.
