# 009-presence-lease

## idea
A small surface for declaring that a person, agent, or session is valid for a specific kind of collaboration for a bounded span of time. Not just online — leased for something.

## principles combined
- Make invisible processes legible
- Turn continuity into infrastructure
- Extend human cognition without obscuring agency
- Push familiar primitives forward instead of inventing novelty for novelty’s sake

## lane
Hybrid

## transformation intent
Opens a path

## what was built
A single-screen prototype for issuing scoped collaboration leases. Each lease defines:
- who or what holds it
- what kind of work it is valid for
- how long the lease lasts
- who backs it
- how confident that validity is

Leases move through three native freshness states:
- fresh
- warming
- expiring

## what is interesting
- It proposes a different primitive than presence status: temporary validity for a kind of work.
- It could apply to human-human, human-agent, and system-mediated collaboration.
- It feels adjacent to tunnels, sleeping machines, handoffs, and review windows without collapsing into generic availability management.
- If the primitive holds, it could open a larger family of collaboration artifacts around scope, trust, expiry, and renewal.

## iterations made
No v1.1 yet. The first version stayed focused on whether the lease primitive itself feels native and fertile.

## next step
Test whether leases get stronger with automatic expiry, linked collaboration actions, and recipient-side acceptance so the primitive becomes something people act through rather than just inspect.

## art direction note
Used the default Night Lab direction with a warm paper-toned editorial surface. The lighter treatment helps the idea feel like a calm operating artifact instead of a system monitor.

## promotion candidate read
Maybe. This feels more like a fertile primitive than a finished product, which is appropriate for the intent, but it still needs proof that “presence lease” is more than elegant framing.
