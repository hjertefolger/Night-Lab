# 010-recurrence-window

## real problem situation
People doing deviation, QA, or incident investigation work often need to tell whether a current incident is truly new or part of a hidden recurring pattern. What goes wrong is that important details are buried in weak summaries and scattered attachments, so recurrence stays invisible until the damage is larger.

## what was built
A comparative recurrence viewer for incident history. Instead of logging new incidents, it lets the viewer inspect one active incident against prior echoes and see where the same pattern keeps resurfacing despite inconsistent summary language.

## why this form was chosen
This needed to be a viewer, not another entry app. The problem is not lack of fields. The problem is that pattern recognition gets buried under bad metadata. A comparison window is more native than a form + board.

## what is actually interesting here
- It treats recurrence as something that can be seen, not just searched.
- It separates headline labels from underlying repeated signals.
- It avoids the Night Lab trap of inventing another mini workflow tool.
- The form is more about inspection and comparison than task entry.

## iterations made
- v1.1 added tighter signal extraction and direct comparison between the active incident and its closest prior echo.

## next step
Test whether the viewer gets stronger with side-by-side attachment excerpts, recurrence confidence weighting, and a mode that shows when a supposedly isolated summary should have triggered historical comparison.

## art direction note
Used the default Night Lab direction with dark mode. The darker treatment fits the forensic/comparative nature of the viewer and keeps attention on signal extraction rather than interface chrome.

## promotion candidate read
Maybe. This is more structurally distinct than the last few builds, and the problem is real, but it still needs proof that the comparison view becomes meaningfully useful rather than just elegant.
