# 008-escalation-shape

## idea
A compact surface for reshaping a request before escalating it: what was tried, what is blocked, what kind of intervention is actually needed, and how urgent the escalation really is.

## principles combined
- Make invisible processes legible
- Extend human cognition without obscuring agency
- Convert deep technical structure into usable product leverage
- Push familiar primitives forward instead of inventing novelty for novelty’s sake

## lane
Hybrid

## transformation intent
Changes collaboration

## what was built
A single-screen prototype with three collaboration states:
- needs shaping
- ready to send
- in motion

Each escalation captures the work title, escalation type, urgency, what was tried, what is needed, and what is blocked. Requests without enough structure stay visibly noisy until they are shaped.

## what is interesting
- It treats escalation quality as a collaboration primitive instead of an email habit.
- It changes behavior by making unshaped requests visibly incomplete.
- It works for human-human, human-agent, and agent-human escalation patterns.
- The board makes escalation load legible without turning into a generic ticketing tool.

## iterations made
No v1.1 yet. The first version stayed focused on whether request-shaping itself feels like the core move.

## next step
Test whether the artifact gets stronger by adding recipient-specific modes, explicit evidence attachments, and a tighter distinction between escalation that needs a decision versus escalation that needs a takeover.

## art direction note
Used the default Night Lab direction with dark mode. The darker editorial treatment gives the board a more operational and inspection-oriented feel without becoming enterprise dashboard chrome.

## promotion candidate read
Maybe. The mechanism feels sharper than a normal request form, but it still needs stronger proof that the shaping model materially improves real collaboration instead of just organizing requests more neatly.
