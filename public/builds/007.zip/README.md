# 007-interrupt-budget

## idea
A small surface for deciding what kinds of interruption are still worth breaking flow for right now, before everything starts feeling equally urgent.

## principles combined
- Make invisible processes legible
- Extend human cognition without obscuring agency
- Compress complexity while preserving essence
- Push familiar primitives forward instead of inventing novelty for novelty’s sake

## lane
Grounded

## transformation intent
Solves

## what was built
A single-screen prototype for assigning incoming interruptions a budget cost and sorting them into three native states:
- yes now
- only if blocked
- can wait

The surface keeps a visible remaining interrupt budget so urgency stops feeling flat and undifferentiated.

## what is interesting
- It turns interruption into a finite resource instead of a vague emotional burden.
- It makes “safe to ignore for now” feel legitimate rather than negligent.
- It solves a real collaboration and overload problem without becoming a task manager.
- The budget mechanic creates a native behavior change instead of relying on explanatory copy.

## iterations made
No v1.1 yet. The first version stayed focused on whether the interrupt-budget mechanic holds on its own.

## next step
Test whether the artifact gets stronger with:
- time windows tied to the current focus block
- second-person negotiation of interruption budgets in teams
- auto-reset between work blocks
- a stronger distinction between interruption cost and interruption importance

## art direction note
Used the default Night Lab direction with a warm paper-toned editorial surface instead of dark mode. The lighter treatment fits the grounded productivity artifact better and avoids dashboard heaviness.

## promotion candidate read
Maybe. The mechanism is practical and distinct, but it needs evidence that the budget model stays useful across repeated real interruption pressure.
