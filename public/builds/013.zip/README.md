# 013-link-mender

## real problem situation
Jira migrations often leave behind dead legacy links in descriptions, comments, remote links, and custom fields. The surface appears migrated, but continuity is quietly broken. Teams then fall into support-grade cleanup rituals, CSV passes, or manual repair work just to restore meaning.

## what was built
A constrained link-repair instrument. Instead of treating broken references as tickets or migration status, the prototype treats each dead link as a continuity break that can be scanned, previewed, and rewritten with different confidence levels.

## why this form was chosen
The native action here is not tracking or discussion. It is repair with confidence. So the artifact had to be a focused repair instrument rather than a board, queue, or issue manager.

## what is actually interesting here
- It reframes migration cleanup as continuity repair.
- It centers scan → preview → rewrite rather than ticket handling.
- It keeps ambiguity visible instead of flattening everything into “fixed” or “broken.”
- It avoids the recent Night Lab trap of turning every problem into another viewer or operational surface.

## iterations made
- No v1.1 or v1.2 pass. The tighter first artifact felt truer than adding more configuration tonight.

## next step
Add host rules, path transforms, and downgrade states so the tool can distinguish safe repair, ambiguous remap, and human review more explicitly.

## art direction note
Used the default Night Lab editorial direction in dark mode. The darker treatment supports the forensic repair feel without becoming dashboard-like.

## promotion candidate read
Maybe. The form is tighter and more operationally native than many recent builds, but it still needs a stronger real repair grammar to become more than a conceptually clean first artifact.
